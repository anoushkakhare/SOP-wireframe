
@echo off
title Unilever Demand Planner - Local Demo

cd /d "%~dp0"

echo ==========================================
echo   UNILEVER DEMAND PLANNER - LOCAL DEMO
echo ==========================================
echo.
echo Starting application...
echo.

start "" http://localhost:5001/login

"%~dp0runtime\node.exe" "%~dp0backend\dist\index.js"

echo.
echo Application stopped.
pause
